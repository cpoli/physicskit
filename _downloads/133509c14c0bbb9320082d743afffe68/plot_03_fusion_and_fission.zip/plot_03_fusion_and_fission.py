r"""
Cockcroft-Walton's disintegration and the discovery of fission
=====================================================================

Cockcroft and Walton (1932) fired accelerated protons at lithium-7 and
found it split into two alpha particles,
:math:`{}^1{\rm H}+{}^7{\rm Li}\to2\,{}^4{\rm He}` -- the first nuclear
reaction ever induced entirely by artificial acceleration, and the first
direct laboratory confirmation of :math:`Q=\Delta mc^2`. Six years later,
Hahn, Strassmann, Meitner, and Frisch found that uranium bombarded by
neutrons could split into two much lighter nuclei, releasing roughly 200
MeV -- because the liquid drop's Coulomb repulsion overwhelms its surface
tension once :math:`Z` is large enough. This example computes both
reactions' energy release with :func:`~physicskit.particle.nuclear.q_value`,
and shows they sit at opposite ends of the same binding-energy curve:
Cockcroft-Walton fuses light nuclei toward the curve's peak, fission
splits a heavy nucleus back down toward it.
"""

# %%
import matplotlib.pyplot as plt
import numpy as np

from physicskit.particle.nuclear import binding_energy_per_nucleon, q_value

# %%
# Cockcroft and Walton: p + Li-7 -> 2 He-4
# ----------------------------------------------
# Rest masses in atomic mass units (u); 1 u = 931.494 MeV.
u_to_MeV = 931.494
m_p = 1.007825
m_li7 = 7.016003
m_he4 = 4.002602

Q_cw = q_value([m_p, m_li7], [m_he4, m_he4]) * u_to_MeV
print(f"Cockcroft-Walton, p + Li-7 -> 2 He-4:  Q = {Q_cw:.3f} MeV")
print("(the historical measurement, from the alpha particles' kinetic energy, matched this to within experimental error --")
print(" the first direct laboratory verification of E=mc^2 in a nuclear reaction)")

# %%
# Fission: a representative split of uranium-236
# ------------------------------------------------------
# A schematic (not the only observed) fission channel: the compound
# nucleus formed by slow-neutron capture on U-235 splits into barium and
# krypton isotopes plus a few free neutrons.
m_n = 1.008665
m_u235 = 235.043930
m_ba141 = 140.914411
m_kr92 = 91.926156

reactants = [m_u235, m_n]
products = [m_ba141, m_kr92] + [m_n] * 3  # U-236* -> Ba-141 + Kr-92 + 3n
Q_fission = q_value(reactants, products) * u_to_MeV
print(f"\nfission, n + U-235 -> Ba-141 + Kr-92 + 3n:  Q = {Q_fission:.1f} MeV")
print("(the same order of magnitude as Meitner and Frisch's original ~200 MeV estimate --")
print(" the exact number depends on which of many possible fission fragment pairs is chosen)")
print(f"ratio to Cockcroft-Walton's release: {Q_fission / Q_cw:.0f}x more energy per reaction")

# %%
# Both sit on opposite slopes of the same binding-energy curve
# --------------------------------------------------------------------
A_values = np.arange(4, 240)
Z_values = np.round(A_values / (2.0 + 0.015 * A_values ** (2.0 / 3.0))).astype(int)
bpn = np.array([binding_energy_per_nucleon(Z, A) for Z, A in zip(Z_values, A_values)])

bpn_li7 = binding_energy_per_nucleon(3, 7)
bpn_he4 = binding_energy_per_nucleon(2, 4)
bpn_u235 = binding_energy_per_nucleon(92, 235)
bpn_ba141 = binding_energy_per_nucleon(56, 141)
bpn_kr92 = binding_energy_per_nucleon(36, 92)

fig, ax = plt.subplots(figsize=(7, 4.8))
ax.plot(A_values, bpn, color="0.4")
ax.scatter([7], [bpn_li7], color="steelblue", zorder=5, s=60, label="Li-7 (Cockcroft-Walton reactant)")
ax.scatter([4], [bpn_he4], color="seagreen", zorder=5, s=60, label="He-4 (Cockcroft-Walton product)")
ax.scatter([235], [bpn_u235], color="firebrick", zorder=5, s=60, label="U-235 (fission reactant)")
ax.scatter([141, 92], [bpn_ba141, bpn_kr92], color="darkorange", zorder=5, s=60, label="Ba-141, Kr-92 (fission products)")
ax.annotate("", xy=(4, bpn_he4 - 0.3), xytext=(7, bpn_li7 - 0.3), arrowprops=dict(arrowstyle="->", color="steelblue"))
ax.annotate("", xy=(115, bpn_ba141 - 0.3), xytext=(235, bpn_u235 - 0.3), arrowprops=dict(arrowstyle="->", color="firebrick"))
ax.set_xlabel("mass number A")
ax.set_ylabel("binding energy per nucleon (MeV)")
ax.set_title("Fusion (light -> heavier) and fission (heavy -> lighter) both climb toward the peak")
ax.legend(fontsize=8, loc="lower right")
fig.tight_layout()

plt.show()
